**RELEASE NOTES HAVE BEEN ORDERED BY MOST RECENT UPDATE AT TOP AND  OLDEST UPDATE AT BOTTOM**



**RELEASE V2**

Second Version of the pack



Gold sword was not loading properly due to having the wrong file name, so that was changed.

Ender Pearl was replaced with the original fireball texture, including the animation.

Fireball was changed to be more detailed and have a glowing fire animation on top

Changed ALL ARMOUR to look titan sized like the leather armor



**RELEASE V1**

5/3/2026

First version of pack



Items changed:



All Swords(Changed to Lightsabers)

Golden Apples/God Apples

Ender Pearl

Fireball

Fire Texture

Leather Armor(Regular, Not Overlay)



Base pack is "Plasma 16x" By Tenoch and Looshy



**To download more versions, Visit the GitHub page for all**

**versions, and CurseForge for latest release.**

